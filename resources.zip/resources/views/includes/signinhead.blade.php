<head>
  <meta charset="utf-8" />
  <title>{{   $company->name }} | Login </title>
  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="{{ asset('/css/bootstraplogin.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('/css/animate.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('/css/font-awesome.min.css')}}" type="text/css" />
  <link rel="stylesheet" href="{{ asset('/css/font.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{ asset('/css/app.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{ asset('/js/toastr/toastr.css')}}" type="text/css" />
  <!--[if lt IE 9]>
    <script src="js/ie/html5shiv.js"></script>
    <script src="js/ie/respond.min.js"></script>
    <script src="js/ie/excanvas.js"></script>
  <![endif]-->
</head>