  <script src="{{ asset('/js/Chart.js')}}"></script>
<div style="width:100%;">
    {!! $diagnosischartjs->render() !!}
</div>


