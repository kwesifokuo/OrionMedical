<!DOCTYPE html>
<html>
<body>
<h2>Congratulations!</h2>
Hello {{ $fullname  }},
<br><br>
Your account has succefully been created with CDH Securities Limited for the purchase and sale of stocks.
<br>
<br>
Thank you.

This email was sent to {{ $fullname  }} (echo.jasonkerr7@gmail.com) regarding your CDH Securities account 
by CDH Securities Limited, Inc, 405 Howard St., Floor 2, San Francisco CA 94105. Unsubscribe
</body>
</html>