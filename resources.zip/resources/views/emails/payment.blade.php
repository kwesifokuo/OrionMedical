<!DOCTYPE html>
<html>
    <body>
        Hello {{ $fullname  }},
        <br><br>
        Your account has been confirmed at CDH Securities Limited.
        Thank You.
    </body>
</html>