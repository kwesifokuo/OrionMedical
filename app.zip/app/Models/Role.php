<?php

namespace OrionMedical\Models;

use Zizaco\Entrust\EntrustRole;

class Role extends EntrustRole
{
    //
}
