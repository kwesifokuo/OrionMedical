<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class RegisteredCompanies extends Model
{
    protected $table = 'companies';

    public $timestamps = false;
}
