<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DrugStore extends Model
{
    protected $table = 'drug_stock_transactions'; //
    public $timestamps = false;
}
