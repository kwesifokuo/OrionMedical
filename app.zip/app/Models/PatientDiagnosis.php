<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientDiagnosis extends Model
{
    protected $table = 'patient_diagnosis';
    public $timestamps = false;
}
