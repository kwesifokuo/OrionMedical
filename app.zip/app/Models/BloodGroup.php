<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class BloodGroup extends Model
{
   protected $table = 'blood_group';
}
