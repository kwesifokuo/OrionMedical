<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Diagnosis extends Model
{
    protected $table = 'diagnosis_local';

    public $timestamps = false;
}
