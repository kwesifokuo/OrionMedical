<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DentalCavity extends Model
{
    
     protected $table = 'tooth_numbering';

}
