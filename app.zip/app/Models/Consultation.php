<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Consultation extends Model
{
    protected $table = 'patient_consultation';
      public $timestamps = false;
}
