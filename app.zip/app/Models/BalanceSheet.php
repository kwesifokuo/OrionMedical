<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class BalanceSheet extends Model
{
     protected $table = 'patient_balance_sheet';

    public $timestamps = false;
}
