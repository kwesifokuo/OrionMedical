<?php

namespace OrionMedical;

use Illuminate\Database\Eloquent\Model;

class GestationPercussion extends Model
{
    //
}
