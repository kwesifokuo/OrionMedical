<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class AdmissionLocation extends Model
{
    protected $table = 'admission_area';
    public $timestamps = false;
}
