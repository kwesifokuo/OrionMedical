<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class LabResultDrop extends Model
{
   protected $table = 'lab_result_selector';
   public $timestamps = false;
}
