<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class VisitType extends Model
{
    protected $table = 'visit_types';
}
