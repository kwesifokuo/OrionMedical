<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class SMS extends Model
{
    protected $table = 'sms_notifications';
    public $timestamps = false;
}
