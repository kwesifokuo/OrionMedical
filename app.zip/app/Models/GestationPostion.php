<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class GestationPostion extends Model
{
    protected $table = 'gestation_position';
}
