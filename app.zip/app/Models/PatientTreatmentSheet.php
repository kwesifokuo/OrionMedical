<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientTreatmentSheet extends Model
{
     protected $table = 'treatment_sheet';
      public $timestamps = false;
}
