<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DrugPeriod extends Model
{
     protected $table = 'drug_period';
}
