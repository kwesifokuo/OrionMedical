<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Treatment extends Model
{
    protected $table = 'service_prices';
}
