<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Nationality extends Model
{
     protected $table = 'nationality';

}
