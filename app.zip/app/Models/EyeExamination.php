<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class EyeExamination extends Model
{
    protected $table = 'eye_examinations';
    public $timestamps = false;
}
