<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientStatement extends Model
{
     protected $table = 'ledger_ext';
}
