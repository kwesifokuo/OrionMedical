<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class OcularExamination extends Model
{
   protected $table = 'ocular_examination';
   public $timestamps = false;
}
