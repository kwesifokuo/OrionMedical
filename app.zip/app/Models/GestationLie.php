<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class GestationLie extends Model
{
    protected $table = 'gestation_lie';
}
