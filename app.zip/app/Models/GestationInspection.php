<?php

namespace OrionMedical;

use Illuminate\Database\Eloquent\Model;

class GestationInspection extends Model
{
    //
}
