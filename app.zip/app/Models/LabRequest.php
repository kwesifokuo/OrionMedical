<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class LabRequest extends Model
{
     protected $table = 'lab_category';
    public $timestamps = false;
}
