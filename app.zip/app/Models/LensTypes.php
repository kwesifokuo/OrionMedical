<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class LensTypes extends Model
{
    protected $table = 'lens_types';
}
