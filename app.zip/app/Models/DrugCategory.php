<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DrugCategory extends Model
{
   protected $table = 'drug_category';
}
