<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientVitals extends Model
{
    protected $table = 'patient_vitals';
    public $timestamps = false;
}
