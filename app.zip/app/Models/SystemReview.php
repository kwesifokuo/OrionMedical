<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class SystemReview extends Model
{
    protected $table = 'system_review_parameter';
}
