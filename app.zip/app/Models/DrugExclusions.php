<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DrugExclusions extends Model
{
    protected $table = 'service_exclusions';
}

