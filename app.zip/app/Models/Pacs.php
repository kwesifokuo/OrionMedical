<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Pacs extends Model
{
   protected $table = 'images_request_types';
   public $timestamps = false;
}
