<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Serial extends Model
{
     protected $table = 'serials';
     public $timestamps = false;
}
