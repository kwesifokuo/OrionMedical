<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class GestationDays extends Model
{
     protected $table = 'gestation_period';
}
