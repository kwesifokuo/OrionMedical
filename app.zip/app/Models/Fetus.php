<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Fetus extends Model
{
   protected $table = 'gestation_festus';
}
