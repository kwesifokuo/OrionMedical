<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class ROS extends Model
{
     protected $table = 'patient_ros';

    public $timestamps = false;
}
