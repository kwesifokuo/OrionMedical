<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Detention extends Model
{
    protected $table = 'detention_list';

    protected $dates =['created_on'];
}
