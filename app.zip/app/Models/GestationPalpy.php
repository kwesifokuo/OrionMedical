<?php

namespace OrionMedical;

use Illuminate\Database\Eloquent\Model;

class GestationPalpy extends Model
{
    //
}
