<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Ward extends Model
{
   protected $table = 'wards';
    public $timestamps = false;
}
