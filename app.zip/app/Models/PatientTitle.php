<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientTitle extends Model
{
    protected $table = 'title';
}
