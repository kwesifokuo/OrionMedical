<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientCategory extends Model
{
   protected $table = 'patient_category';
}
