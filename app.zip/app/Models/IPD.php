<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class IPD extends Model
{
    protected $table = 'ipd';
    public $timestamps = false;
}
