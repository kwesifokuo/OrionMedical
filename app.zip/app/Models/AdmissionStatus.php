<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class AdmissionStatus extends Model
{
    protected $table = 'admission_status';
    public $timestamps = false;
}
