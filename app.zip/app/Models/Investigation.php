<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Investigation extends Model
{
    protected $table = 'investigations';

    public $timestamps = false;
}
