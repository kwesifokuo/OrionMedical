<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class LensTreatment extends Model
{
    protected $table = 'lens_treatment';
}
