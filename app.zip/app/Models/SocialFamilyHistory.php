<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class SocialFamilyHistory extends Model
{
  protected $table = 'social_family_history';
  public $timestamps = false;
}
