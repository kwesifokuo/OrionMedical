<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientProcedure extends Model
{
    protected $table = 'patient_procedures';
     public $timestamps = false;
}
