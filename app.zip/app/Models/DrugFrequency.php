<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DrugFrequency extends Model
{
    protected $table = 'drug_frequency';
}
