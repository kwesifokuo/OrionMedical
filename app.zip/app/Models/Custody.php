<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Custody extends Model
{
    protected $table = 'custody';

    public $timestamps = false;
}
