<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Relationships extends Model
{
    protected $table = 'relationships';

}
