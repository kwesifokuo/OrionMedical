<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientTreatment extends Model
{
    protected $table = 'patient_treatment';
}
