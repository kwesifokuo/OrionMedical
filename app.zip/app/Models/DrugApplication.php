<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DrugApplication extends Model
{
   protected $table = 'dosage_remarks';
}
