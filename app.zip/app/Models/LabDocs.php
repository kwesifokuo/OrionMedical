<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class LabDocs extends Model
{
    protected $table = 'lab_documents';
    public $timestamps = false;
}
