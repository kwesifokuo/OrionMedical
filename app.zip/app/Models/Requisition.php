<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class Requisition extends Model
{
     protected $table = 'requisitions';
}
