<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class ImagingRequest extends Model
{
    public $timestamps = false;
	 protected $table = 'imaging_request';
}
