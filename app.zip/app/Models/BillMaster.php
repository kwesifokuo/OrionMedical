<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class BillMaster extends Model
{
     protected $table = 'master_bill_list';

    

}
