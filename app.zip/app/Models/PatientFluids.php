<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientFluids extends Model
{
   protected $table = 'patient_fluids';
   public $timestamps = false;
}
