<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class mPharma extends Model
{
     protected $table = 'drugs_dispensed';
}
