<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class DrugDosage extends Model
{
   protected $table = 'dosages';
}
