<?php

namespace OrionMedical\Models;

use Illuminate\Database\Eloquent\Model;

class PatientFurtherPlan extends Model
{
     protected $table = 'patient_procedures_future';
     public $timestamps = false;
}
